/* ================================
   SQUAD — Main Application Script
   ================================ */

// ============================================
// 1. DATA
// ============================================

const GAMES = {
  Valorant:  { icon: 'assets/icons/valorant.svg',  color: '#FF4655' },
  'CS2':     { icon: 'assets/icons/cs2.svg',       color: '#F5A623' },
  'Dota 2':  { icon: 'assets/icons/dota2.svg',      color: '#E55D2B' },
  'League of Legends': { icon: 'assets/icons/lol.svg', color: '#C89B3C' },
  'Apex Legends': { icon: 'assets/icons/apex.svg',  color: '#DA3832' }
};

const RANKS = ['Iron','Bronze','Silver','Gold','Platinum','Diamond','Ascendant','Immortal','Radiant'];
const ROLES  = ['Duelist','Controller','Support','Carry','Mid','AWPer','IGL'];

const STATUSES = { looking: 'Ищу команду', playing: 'В игре', offline: 'Оффлайн' };

const DEFAULT_PLAYERS = [
  { id: 'p1', nick: 'Nagibator2000', country: '🇷🇺', game: 'Valorant', rank: 'Gold', role: 'Duelist', mic: true, status: 'looking', timezone: 'UTC+3', desc: 'Играю вечером, без токсичности', badges: ['nontoxic','stable'], rating: 4.8, registered: '2026-05-10' },
  { id: 'p2', nick: 'ProSupport', country: '🇺', game: 'Dota 2', rank: 'Immortal', role: 'Support', mic: true, status: 'looking', timezone: 'UTC-5', desc: 'Ищу керри для буста', badges: ['verified','stable'], rating: 4.9, registered: '2026-04-20' },
  { id: 'p3', nick: 'SniperElite', country: '🇰🇷', game: 'CS2', rank: 'Silver', role: 'AWPer', mic: true, status: 'looking', timezone: 'UTC+9', desc: 'Только серьезная игра', badges: ['verified'], rating: 4.7, registered: '2026-05-01' },
  { id: 'p4', nick: 'ChillPlayer', country: '🇧', game: 'Apex Legends', rank: 'Platinum', role: 'Support', mic: false, status: 'playing', timezone: 'UTC-3', desc: 'Играю расслабленно, без рейтинга', badges: ['nontoxic'], rating: 4.2, registered: '2026-05-15' },
  { id: 'p5', nick: 'MidOrFeed', country: '🇷🇺', game: 'League of Legends', rank: 'Diamond', role: 'Mid', mic: true, status: 'looking', timezone: 'UTC+3', desc: 'Ищу тиммейтов для ranked', badges: ['stable'], rating: 4.6, registered: '2026-04-10' },
  { id: 'p6', nick: 'NewbieFriendly', country: '🇷', game: 'Valorant', rank: 'Silver', role: 'Controller', mic: true, status: 'looking', timezone: 'UTC+3', desc: 'Обучаюсь, ищу таких же', badges: ['nontoxic'], rating: 4.0, registered: '2026-06-01' },
  { id: 'p7', nick: 'TournamentPro', country: '🇺', game: 'CS2', rank: 'Gold', role: 'IGL', mic: true, status: 'looking', timezone: 'UTC-5', desc: 'Собираю команду на турнир', badges: ['verified','stable'], rating: 4.9, registered: '2026-03-15' },
  { id: 'p8', nick: 'NightOwl', country: '🇰🇿', game: 'Dota 2', rank: 'Platinum', role: 'Carry', mic: true, status: 'looking', timezone: 'UTC+6', desc: 'Играю ночью, EU сервер', badges: ['stable','streak'], rating: 4.5, registered: '2026-05-20' },
  { id: 'p9', nick: 'ShadowStrike', country: '🇩', game: 'Valorant', rank: 'Radiant', role: 'Duelist', mic: true, status: 'looking', timezone: 'UTC+1', desc: 'Топ-ранг, ищу серьезных тиммейтов', badges: ['verified','nontoxic','stable'], rating: 5.0, registered: '2026-02-10' },
  { id: 'p10', nick: 'IceBreaker', country: '🇫', game: 'League of Legends', rank: 'Bronze', role: 'Support', mic: false, status: 'offline', timezone: 'UTC+2', desc: 'Учусь играть, нужен наставник', badges: [], rating: 3.2, registered: '2026-05-25' }
];

// ============================================
// 2. STATE
// ============================================

let state = loadState();

function defaultState() {
  return {
    players: JSON.parse(JSON.stringify(DEFAULT_PLAYERS)),
    profile: null,
    favorites: [],
    requests: { incoming: [], outgoing: [] },
    filters: { game: 'all', ranks: [], roles: [], mic: false, sort: 'online', search: '' },
    notifCount: 0,
    nextId: 20
  };
}

function loadState() {
  try {
    const saved = localStorage.getItem('squad_state');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && parsed.players && parsed.players.length > 0) return parsed;
    }
  } catch (_) {}
  return defaultState();
}

function saveState() {
  try { localStorage.setItem('squad_state', JSON.stringify(state)); } catch (_) {}
}

// ============================================
// 3. HELPERS
// ============================================

function getRankClass(rank) {
  const map = { 'Iron':'iron','Bronze':'bronze','Silver':'silver','Gold':'gold','Platinum':'platinum','Diamond':'diamond','Ascendant':'ascendant','Immortal':'immortal','Radiant':'radiant' };
  return map[rank] || 'iron';
}

function getAvatarLetter(nick) { return nick.charAt(0).toUpperCase(); }

function getGameIcon(game) { return GAMES[game]?.icon || ''; }

function statusDot(s) {
  if (s === 'looking') return 'online';
  if (s === 'playing') return 'ingame';
  return 'offline';
}

function statusLabel(s) { return STATUSES[s] || s; }

function getBadgeLabel(b) {
  return { verified: 'Проверенный', nontoxic: 'Без токсичности', stable: 'Стабильный онлайн', streak: '7 дней подряд' }[b] || b;
}

function getBadgeClass(b) {
  return { verified:'verified', nontoxic:'nontoxic', stable:'stable', streak:'streak' }[b] || '';
}

function starsHTML(rating) {
  const full = Math.floor(rating);
  let h = '';
  for (let i = 0; i < 5; i++) {
    h += `<svg viewBox="0 0 20 20"${i < full ? ' style="fill:#f0a500"' : ' style="fill:#333"'}>
      <path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.58l-4.77 2.5.91-5.33L2.27 6.62l5.34-.78L10 1z"/></svg>`;
  }
  return h;
}

function getScore(p) {
  let s = 0;
  if (p.status === 'looking') s += 100;
  else if (p.status === 'playing') s += 50;
  s += (p.rating || 0) * 10;
  if (p.badges && p.badges.includes('verified')) s += 20;
  if (p.badges && p.badges.includes('stable')) s += 10;
  return s;
}

// ============================================
// 4. RENDER
// ============================================

function renderPlayerCard(p, featured) {
  const rankCls = getRankClass(p.rank);
  const isFav = state.favorites.includes(p.id);
  const hasReq = state.requests.outgoing.some(r => r.toId === p.id);

  return `
    <div class="player-card" data-id="${p.id}" tabindex="0" role="button" aria-label="Профиль ${p.nick}">
      <div class="player-card__header">
        <div class="player-card__avatar player-card__avatar--${rankCls}">
          ${getAvatarLetter(p.nick)}
        </div>
        <div class="player-card__info">
          <div class="player-card__nick">
            ${p.nick}
            <span class="player-card__country">${p.country}</span>
          </div>
          <div class="player-card__game">
            <img src="${getGameIcon(p.game)}" alt="${p.game}" width="18" height="18" loading="lazy">
            ${p.game}
          </div>
        </div>
        <div class="player-card__rating">${starsHTML(p.rating)}</div>
      </div>

      <div class="player-card__badges">
        ${(p.badges||[]).map(b => `<span class="player-card__badge player-card__badge--${getBadgeClass(b)}">${getBadgeLabel(b)}</span>`).join('')}
      </div>

      <div class="player-card__meta">
        <span class="player-card__rank-badge player-card__rank-badge--${rankCls}">${p.rank}</span>
        <span class="player-card__role">${p.role}</span>
        <span class="player-card__status">
          <span class="player-card__status-dot player-card__status-dot--${statusDot(p.status)}"></span>
          ${statusLabel(p.status)}
        </span>
        ${p.mic ? '<span class="player-card__mic">🎤</span>' : '<span class="player-card__mic" style="opacity:0.3">❌</span>'}
        <span class="player-card__timezone">${p.timezone}</span>
      </div>

      <div class="player-card__desc">${p.desc || ''}</div>

      <div class="player-card__actions">
        <button class="btn btn--primary btn--sm request-btn" data-id="${p.id}" ${hasReq ? 'disabled' : ''}>${hasReq ? 'Заявка отправлена' : 'В заявку'}</button>
        <button class="btn btn--secondary btn--sm" data-id="${p.id}" data-action="message">Написать</button>
        <button class="btn btn--icon btn--sm fav-btn ${isFav ? 'active' : ''}" data-id="${p.id}" aria-label="${isFav ? 'Убрать из избранного' : 'В избранное'}">
          <svg viewBox="0 0 24 24" width="16" height="16"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1.5"/></svg>
        </button>
      </div>
    </div>`;
}

function renderFeatured() {
  const looking = state.players.filter(p => p.status === 'looking').sort((a,b) => (b.rating||0)-(a.rating||0)).slice(0, 3);
  const grid = document.getElementById('featuredGrid');
  if (!grid) return;
  if (looking.length === 0) {
    grid.innerHTML = '<p style="color:#666;text-align:center;padding:40px 0;">Сейчас нет игроков в поиске</p>';
    return;
  }
  grid.innerHTML = looking.map(p => renderPlayerCard(p, true)).join('');
}

function renderAll() {
  const grid = document.getElementById('playersGrid');
  const empty = document.getElementById('emptyState');
  if (!grid) return;

  const filtered = getFilteredPlayers();

  if (filtered.length === 0) {
    grid.innerHTML = '';
    if (empty) empty.classList.add('visible');
    return;
  }
  if (empty) empty.classList.remove('visible');
  grid.innerHTML = filtered.map(p => renderPlayerCard(p)).join('');
}

function getFilteredPlayers() {
  const f = state.filters;
  let list = [...state.players];

  // Search
  if (f.search) {
    const q = f.search.toLowerCase();
    list = list.filter(p => p.nick.toLowerCase().includes(q));
  }

  // Game
  if (f.game !== 'all') {
    list = list.filter(p => p.game === f.game);
  }

  // Ranks
  if (f.ranks.length > 0) {
    list = list.filter(p => f.ranks.includes(p.rank));
  }

  // Roles
  if (f.roles.length > 0) {
    list = list.filter(p => f.roles.includes(p.role));
  }

  // Mic
  if (f.mic) {
    list = list.filter(p => p.mic);
  }

  // Sort
  if (f.sort === 'online') {
    list.sort((a, b) => {
      const oA = a.status === 'looking' ? 2 : a.status === 'playing' ? 1 : 0;
      const oB = b.status === 'looking' ? 2 : b.status === 'playing' ? 1 : 0;
      if (oB !== oA) return oB - oA;
      return getScore(b) - getScore(a);
    });
  } else if (f.sort === 'rank') {
    const rankOrder = { 'Iron':1,'Bronze':2,'Silver':3,'Gold':4,'Platinum':5,'Diamond':6,'Ascendant':7,'Immortal':8,'Radiant':9 };
    list.sort((a,b) => (rankOrder[b.rank]||0) - (rankOrder[a.rank]||0));
  } else if (f.sort === 'newest') {
    list.sort((a,b) => new Date(b.registered) - new Date(a.registered));
  }

  return list;
}

function renderRequests(tab) {
  const container = document.getElementById('requestsList');
  if (!container) return;

  const t = tab || 'incoming';
  const items = state.requests[t] || [];

  if (items.length === 0) {
    container.innerHTML = `<p style="color:#666;text-align:center;padding:40px 0;">Нет ${t === 'incoming' ? 'входящих' : 'исходящих'} заявок</p>`;
    return;
  }

  container.innerHTML = items.map(r => {
    const player = state.players.find(p => p.id === (t === 'incoming' ? r.fromId : r.toId));
    if (!player) return '';
    const rankCls = getRankClass(player.rank);
    return `
      <div class="request-item">
        <div class="request-item__avatar player-card__avatar--${rankCls}">${getAvatarLetter(player.nick)}</div>
        <div class="request-item__info">
          <div class="request-item__nick">${player.nick}</div>
          <div class="request-item__meta">${player.game} · ${player.rank} · ${player.role}</div>
        </div>
        ${t === 'incoming' ? `
          <div class="request-item__actions">
            <button class="btn btn--primary btn--sm req-action" data-action="accept" data-id="${r.id}">Принять</button>
            <button class="btn btn--danger btn--sm req-action" data-action="reject" data-id="${r.id}">Отклонить</button>
          </div>
        ` : `
          <span class="request-item__status request-item__status--${r.status}">${r.status === 'pending' ? 'Ожидает' : r.status === 'accepted' ? 'Принята' : 'Отклонена'}</span>
        `}
      </div>`;
  }).join('');
}

function renderProfile(playerId) {
  const container = document.getElementById('profileContent');
  if (!container) return;

  const p = state.players.find(x => x.id === playerId);
  if (!p) { container.innerHTML = '<p>Игрок не найден</p>'; return; }

  const rankCls = getRankClass(p.rank);
  const isFav = state.favorites.includes(p.id);
  const hasReq = state.requests.outgoing.some(r => r.toId === p.id);
  const outgoing = state.requests.outgoing.filter(r => r.toId === p.id);

  container.innerHTML = `
    <div class="profile-detail">
      <div class="profile-detail__avatar player-card__avatar--${rankCls}">${getAvatarLetter(p.nick)}</div>
      <div>
        <div class="profile-detail__nick">${p.nick} ${p.country}</div>
        <div class="profile-detail__game">
          <img src="${getGameIcon(p.game)}" alt="${p.game}" width="18" height="18" style="display:inline;vertical-align:middle;">
          ${p.game} · ${p.rank} · ${p.role}
        </div>
        <div style="margin-top:6px;">
          <span class="player-card__status">
            <span class="player-card__status-dot player-card__status-dot--${statusDot(p.status)}"></span>
            ${statusLabel(p.status)}
          </span>
          ${p.mic ? ' · 🎤 Микрофон есть' : ' · ❌ Без микрофона'}
          · <span class="player-card__timezone">${p.timezone}</span>
        </div>
      </div>
    </div>

    <div style="margin-bottom:16px;font-size:0.9rem;color:var(--text-secondary);">
      ${p.desc || ''}
    </div>

    <div class="player-card__badges" style="margin-bottom:16px;">
      ${(p.badges||[]).map(b => `<span class="player-card__badge player-card__badge--${getBadgeClass(b)}">${getBadgeLabel(b)}</span>`).join('')}
    </div>

    <div class="profile-stats">
      <div class="profile-stat">
        <div class="profile-stat__value">${p.rating}</div>
        <div class="profile-stat__label">Рейтинг</div>
      </div>
      <div class="profile-stat">
        <div class="profile-stat__value">${outgoing.filter(r => r.status === 'accepted').length}</div>
        <div class="profile-stat__label">Сыграно матчей</div>
      </div>
      <div class="profile-stat">
        <div class="profile-stat__value">${new Date(p.registered).toLocaleDateString('ru-RU', {month:'short',day:'numeric'})}</div>
        <div class="profile-stat__label">На сайте с</div>
      </div>
    </div>

    <div class="player-card__actions">
      <button class="btn btn--primary request-btn" data-id="${p.id}" ${hasReq ? 'disabled' : ''}>${hasReq ? 'Заявка отправлена' : 'Отправить заявку'}</button>
      <button class="btn btn--secondary" data-id="${p.id}" data-action="message">Написать</button>
      <button class="btn btn--icon fav-btn ${isFav ? 'active' : ''}" data-id="${p.id}" aria-label="${isFav ? 'Убрать из избранного' : 'В избранное'}">
        <svg viewBox="0 0 24 24" width="18" height="18"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="1.5"/></svg>
      </button>
    </div>`;
}

// ============================================
// 5. MODALS
// ============================================

function openModal(id) {
  const m = document.getElementById(id);
  if (!m) return;
  m.classList.add('open');
  document.body.style.overflow = 'hidden';
  const firstInput = m.querySelector('input, select, textarea, button:not(.modal__close)');
  if (firstInput) setTimeout(() => firstInput.focus(), 100);
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (!m) return;
  m.classList.remove('open');
  document.body.style.overflow = '';
}

function closeAllModals() {
  document.querySelectorAll('.modal.open').forEach(m => {
    m.classList.remove('open');
  });
  document.body.style.overflow = '';
}

// ============================================
// 6. TOAST
// ============================================

function showToast(msg, type) {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const t = document.createElement('div');
  t.className = `toast toast--${type || 'info'}`;
  t.textContent = msg;
  container.appendChild(t);
  setTimeout(() => {
    t.classList.add('out');
    setTimeout(() => t.remove(), 300);
  }, 3000);
}

// ============================================
// 7. ACTIONS
// ============================================

function sendRequest(playerId) {
  if (!state.profile) {
    showToast('Сначала создайте профиль в разделе "Добавить себя"', 'error');
    return;
  }
  if (state.requests.outgoing.some(r => r.toId === playerId)) {
    showToast('Заявка уже отправлена', 'info');
    return;
  }
  const id = 'req_' + Date.now();
  state.requests.outgoing.push({ id, fromId: state.profile.id, toId: playerId, status: 'pending' });
  state.requests.incoming.push({ id, fromId: state.profile.id, toId: playerId, status: 'pending' });

  // Also add to target player's incoming (if we simulate other profiles)
  state.notifCount++;
  saveState();
  updateNotifCount();
  renderAll();
  renderFeatured();
  showToast('Заявка отправлена!', 'success');
}

function acceptRequest(reqId) {
  const req = state.requests.incoming.find(r => r.id === reqId);
  if (!req) return;
  req.status = 'accepted';
  const out = state.requests.outgoing.find(r => r.id === reqId);
  if (out) out.status = 'accepted';
  saveState();
  renderRequests('incoming');
  showToast('Заявка принята! Теперь вы тиммейты', 'success');
}

function rejectRequest(reqId) {
  const req = state.requests.incoming.find(r => r.id === reqId);
  if (!req) return;
  req.status = 'rejected';
  const out = state.requests.outgoing.find(r => r.id === reqId);
  if (out) out.status = 'rejected';
  saveState();
  renderRequests('incoming');
  showToast('Заявка отклонена', 'info');
}

function toggleFavorite(playerId) {
  const idx = state.favorites.indexOf(playerId);
  if (idx > -1) {
    state.favorites.splice(idx, 1);
    showToast('Убрано из избранного', 'info');
  } else {
    state.favorites.push(playerId);
    showToast('Добавлено в избранное', 'success');
  }
  saveState();
  renderAll();
  renderFeatured();
}

function addPlayer(data) {
  const id = 'p' + state.nextId++;
  const player = {
    id,
    nick: data.nick,
    country: data.country || '🇷🇺',
    game: data.game,
    rank: data.rank,
    role: data.role,
    mic: data.mic === 'true' || data.mic === true,
    status: 'looking',
    timezone: data.timezone || 'UTC+3',
    desc: data.desc || '',
    badges: ['nontoxic'],
    rating: 3.0,
    registered: new Date().toISOString().slice(0, 10)
  };
  state.players.unshift(player);
  state.profile = player;
  saveState();
  renderAll();
  renderFeatured();
  closeModal('modalAdd');
  showToast('Профиль опубликован! Тебя могут найти тиммейты', 'success');
}

// ============================================
// 8. UPDATE UI
// ============================================

function updateNotifCount() {
  const el = document.getElementById('notifCount');
  if (!el) return;
  const count = state.requests.incoming.filter(r => r.status === 'pending').length;
  el.textContent = count;
  el.style.display = count > 0 ? 'flex' : 'none';
}

function updateOnlineCounter() {
  const el = document.getElementById('onlineCount');
  if (!el) return;
  const looking = state.players.filter(p => p.status === 'looking').length;
  animateCounter(el, looking);
}

function animateCounter(el, target) {
  const duration = 1500;
  const start = parseInt(el.textContent) || 0;
  const diff = target - start;
  if (diff === 0) return;
  const startTime = performance.now();
  function step(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + diff * eased);
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ============================================
// 9. EVENT BINDING
// ============================================

function init() {
  // Render initial
  renderAll();
  renderFeatured();
  updateNotifCount();
  updateOnlineCounter();

  // Search (debounced)
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        state.filters.search = searchInput.value;
        saveState();
        renderAll();
      }, 300);
    });
  }

  // Game filter
  const gameFilter = document.getElementById('gameFilter');
  if (gameFilter) {
    gameFilter.addEventListener('change', () => {
      state.filters.game = gameFilter.value;
      saveState();
      renderAll();
      renderFeatured();
    });
  }

  // Rank chips
  document.querySelectorAll('#rankFilter .chip input').forEach(cb => {
    cb.addEventListener('change', () => {
      state.filters.ranks = Array.from(document.querySelectorAll('#rankFilter .chip input:checked')).map(c => c.value);
      saveState();
      renderAll();
    });
  });

  // Role chips
  document.querySelectorAll('#roleFilter .chip input').forEach(cb => {
    cb.addEventListener('change', () => {
      state.filters.roles = Array.from(document.querySelectorAll('#roleFilter .chip input:checked')).map(c => c.value);
      saveState();
      renderAll();
    });
  });

  // Mic toggle
  const micFilter = document.getElementById('micFilter');
  if (micFilter) {
    micFilter.addEventListener('change', () => {
      state.filters.mic = micFilter.checked;
      saveState();
      renderAll();
    });
  }

  // Sort
  const sortFilter = document.getElementById('sortFilter');
  if (sortFilter) {
    sortFilter.addEventListener('change', () => {
      state.filters.sort = sortFilter.value;
      saveState();
      renderAll();
    });
  }

  // Burger menu
  const burgerBtn = document.getElementById('burgerBtn');
  const mainNav = document.getElementById('mainNav');
  if (burgerBtn && mainNav) {
    burgerBtn.addEventListener('click', () => {
      const open = mainNav.classList.toggle('open');
      burgerBtn.classList.toggle('active');
      burgerBtn.setAttribute('aria-expanded', open);
    });

    // Close nav on link click
    mainNav.querySelectorAll('.header__nav-link').forEach(link => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('open');
        burgerBtn.classList.remove('active');
        burgerBtn.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Add self button and modal
  document.getElementById('btnAddSelf')?.addEventListener('click', () => {
    openModal('modalAdd');
  });

  // Profile edit button (from nav)
  document.getElementById('navProfile')?.addEventListener('click', (e) => {
    e.preventDefault();
    if (!state.profile) {
      showToast('Сначала создайте профиль', 'info');
      return;
    }
    renderMyProfile();
    openModal('modalEditProfile');
  });

  // Requests button
  document.getElementById('navRequests')?.addEventListener('click', (e) => {
    e.preventDefault();
    renderRequests('incoming');
    openModal('modalRequests');
  });

  // Notification button
  document.getElementById('notifBtn')?.addEventListener('click', () => {
    document.getElementById('navRequests')?.click();
  });

  // Show all button
  document.getElementById('showAllBtn')?.addEventListener('click', () => {
    document.getElementById('players')?.scrollIntoView({ behavior: 'smooth' });
  });

  // Hero buttons
  document.querySelector('.hero__btn--primary')?.addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('players')?.scrollIntoView({ behavior: 'smooth' });
  });

  // ============================================
  // EVENT DELEGATION
  // ============================================

  document.addEventListener('click', (e) => {
    // Modal close buttons
    if (e.target.closest('.modal__close') || e.target.closest('.modal__overlay')) {
      const modal = e.target.closest('.modal');
      if (modal) closeModal(modal.id);
    }

    // Modal cancel buttons
    if (e.target.closest('.modal__cancel')) {
      const modal = e.target.closest('.modal');
      if (modal) closeModal(modal.id);
    }

    // Request button on cards
    const reqBtn = e.target.closest('.request-btn');
    if (reqBtn && !reqBtn.disabled) {
      e.stopPropagation();
      sendRequest(reqBtn.dataset.id);
    }

    // Favorite button
    const favBtn = e.target.closest('.fav-btn');
    if (favBtn) {
      e.stopPropagation();
      toggleFavorite(favBtn.dataset.id);
    }

    // Message button
    const msgBtn = e.target.closest('[data-action="message"]');
    if (msgBtn) {
      e.stopPropagation();
      showToast('Чат откроется в следующем обновлении', 'info');
    }

    // Request actions (accept/reject)
    const reqAction = e.target.closest('.req-action');
    if (reqAction) {
      const action = reqAction.dataset.action;
      const id = reqAction.dataset.id;
      if (action === 'accept') acceptRequest(id);
      else if (action === 'reject') rejectRequest(id);
    }

    // Requests tabs
    const tab = e.target.closest('.requests-tab');
    if (tab) {
      document.querySelectorAll('.requests-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderRequests(tab.dataset.tab);
    }

    // Player card click -> open profile
    const card = e.target.closest('.player-card');
    if (card && !e.target.closest('button')) {
      renderProfile(card.dataset.id);
      openModal('modalProfile');
    }
  });

  // ============================================
  // FORM: Add yourself
  // ============================================

  document.getElementById('addForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const form = e.target;
    const data = {
      nick: form.querySelector('#addNick').value.trim(),
      country: form.querySelector('#addCountry').value,
      game: form.querySelector('#addGame').value,
      rank: form.querySelector('#addRank').value,
      role: form.querySelector('#addRole').value,
      mic: form.querySelector('#addMic').value,
      timezone: form.querySelector('#addTimezone').value,
      desc: form.querySelector('#addDesc').value.trim()
    };
    if (!data.nick) { showToast('Введите никнейм', 'error'); return; }
    addPlayer(data);
    form.reset();
  });

  // Keyboard: Escape closes modals
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeAllModals();
    }
    // Close burger on Escape
    if (e.key === 'Escape' && mainNav?.classList.contains('open')) {
      mainNav.classList.remove('open');
      burgerBtn?.classList.remove('active');
      burgerBtn?.setAttribute('aria-expanded', 'false');
    }
  });

  // Restore filter state
  restoreFilterUI();
}

function restoreFilterUI() {
  const f = state.filters;
  const sf = document.getElementById('sortFilter');
  if (sf && f.sort) sf.value = f.sort;
  const gf = document.getElementById('gameFilter');
  if (gf && f.game) gf.value = f.game;
  const mf = document.getElementById('micFilter');
  if (mf && f.mic) mf.checked = f.mic;
  // Restore rank chips
  if (f.ranks && f.ranks.length) {
    document.querySelectorAll('#rankFilter .chip input').forEach(cb => {
      if (f.ranks.includes(cb.value)) cb.checked = true;
    });
  }
  // Restore role chips
  if (f.roles && f.roles.length) {
    document.querySelectorAll('#roleFilter .chip input').forEach(cb => {
      if (f.roles.includes(cb.value)) cb.checked = true;
    });
  }
}

// ============================================
// 10. MY PROFILE
// ============================================

function renderMyProfile() {
  const container = document.getElementById('myProfileContent');
  if (!container || !state.profile) return;

  const p = state.profile;
  const sent = state.requests.outgoing.length;
  const accepted = state.requests.outgoing.filter(r => r.status === 'accepted').length;

  container.innerHTML = `
    <form id="editProfileForm">
      <div class="form-group">
        <label for="editNick">Никнейм</label>
        <input type="text" id="editNick" value="${p.nick}">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="editGame">Игра</label>
          <select id="editGame">
            ${Object.keys(GAMES).map(g => `<option value="${g}"${p.game===g?' selected':''}>${g}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label for="editRank">Ранг</label>
          <select id="editRank">
            ${RANKS.map(r => `<option value="${r}"${p.rank===r?' selected':''}>${r}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label for="editRole">Роль</label>
          <select id="editRole">
            ${ROLES.map(r => `<option value="${r}"${p.role===r?' selected':''}>${r}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label for="editMic">Микрофон</label>
          <select id="editMic">
            <option value="true"${p.mic?' selected':''}>Есть</option>
            <option value="false"${!p.mic?' selected':''}>Нет</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label for="editDesc">Описание</label>
        <textarea id="editDesc" rows="2">${p.desc || ''}</textarea>
      </div>

      <div class="profile-stats" style="margin-top:16px;">
        <div class="profile-stat">
          <div class="profile-stat__value">${p.rating}</div>
          <div class="profile-stat__label">Рейтинг</div>
        </div>
        <div class="profile-stat">
          <div class="profile-stat__value">${sent}</div>
          <div class="profile-stat__label">Отправлено заявок</div>
        </div>
        <div class="profile-stat">
          <div class="profile-stat__value">${accepted}</div>
          <div class="profile-stat__label">Принято заявок</div>
        </div>
      </div>

      <div class="form-actions">
        <button type="button" class="btn btn--secondary modal__cancel">Закрыть</button>
        <button type="submit" class="btn btn--primary">СОХРАНИТЬ</button>
      </div>
    </form>`;

  document.getElementById('editProfileForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const f = e.target;
    p.nick = f.querySelector('#editNick').value.trim() || p.nick;
    p.game = f.querySelector('#editGame').value;
    p.rank = f.querySelector('#editRank').value;
    p.role = f.querySelector('#editRole').value;
    p.mic = f.querySelector('#editMic').value === 'true';
    p.desc = f.querySelector('#editDesc').value.trim();
    // Update in players list
    const idx = state.players.findIndex(x => x.id === p.id);
    if (idx > -1) state.players[idx] = p;
    saveState();
    renderAll();
    renderFeatured();
    showToast('Профиль обновлён', 'success');
  });
}

// ============================================
// 11. INIT
// ============================================

document.addEventListener('DOMContentLoaded', init);
